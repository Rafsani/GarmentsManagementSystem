from django.contrib import admin
from  .models import Employee,Garment,Products
admin.site.register(Employee)
admin.site.register(Garment)
admin.site.register(Products)
# Register your models here.
