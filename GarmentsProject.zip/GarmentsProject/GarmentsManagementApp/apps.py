from django.apps import AppConfig


class GarmentsmanagementappConfig(AppConfig):
    name = 'GarmentsManagementApp'
